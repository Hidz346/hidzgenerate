-- Jalankan di Supabase Dashboard > SQL Editor > New query
-- Prasyarat: bucket bernama "hidzgenerate" sudah dibuat lewat Storage > New bucket,
-- dengan toggle "Public bucket" AKTIF.

-- Izinkan siapa saja (tanpa login) MEMBACA file di bucket hidzgenerate
-- (perlu ini biar link hasil upload bisa dibuka buat di-scan QR-nya)
drop policy if exists "hidzgenerate public read" on storage.objects;
create policy "hidzgenerate public read"
on storage.objects for select
using ( bucket_id = 'hidzgenerate' );

-- Izinkan siapa saja (tanpa login) MENGUPLOAD file ke bucket hidzgenerate
drop policy if exists "hidzgenerate public upload" on storage.objects;
create policy "hidzgenerate public upload"
on storage.objects for insert
with check ( bucket_id = 'hidzgenerate' );
